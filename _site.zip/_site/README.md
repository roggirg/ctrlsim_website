Website available here:

[https://montrealrobotics.ca/ctrlsim/](https://montrealrobotics.ca/ctrlsim/)

---

To install+run locally:

Install dependencies: `bundle install`

Run: `bundle exec jekyll serve`

Or follow more detailed instructions here: https://docs.github.com/en/pages/setting-up-a-github-pages-site-with-jekyll/testing-your-github-pages-site-locally-with-jekyll